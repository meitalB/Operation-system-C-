/******************************************
* Student name: Meital Birka
* Student: 311124283
* Course Exercise Group: 03
* Exercise name: Exercise 1
******************************************/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <wait.h>
#include <stdlib.h>

#define SIZE 1
//struct to all the student information
//add char to char*
//const char *s -the"string"
//char c the add char
//return the current string with the new char
struct studentInfo{
    char* name;
    int ERROR_COMPILATION ;
    int WRONG_DIRECTORY;
    int NO_C_FILE;
    int BAD_OUTPUT;
    int SIMILLAR_OUTPUT;
    int SAME_OUTPUT;
    int TIME_OUT;
    int MULTIPLE_DIRECTORIES;

};
/************************************************************************
 name function: initstudentInfo
The Input:struct studentInfo  currentStudent[], int numOfStudent
The output : no output
The function operation:init all the flags of the struct
 *************************************************************************/
void initStudenInfo( struct studentInfo  currentStudent[], int numOfStudent){
    int i=0;
    while(i<numOfStudent) {
        currentStudent[i].name = "";
        currentStudent[i].ERROR_COMPILATION = 0;
        currentStudent[i].NO_C_FILE = 1;

        currentStudent[i].WRONG_DIRECTORY=0;
        currentStudent[i].BAD_OUTPUT=0;
        currentStudent[i].SIMILLAR_OUTPUT=0;
        currentStudent[i].SAME_OUTPUT=1;
        currentStudent[i].TIME_OUT=0;
        currentStudent[i].MULTIPLE_DIRECTORIES=0;

        i++;
    }
}
/************************************************************************
 name function: append
The Input:append char c to char*s
The output : the full new char*
The function operation:add the char to the end of the current char*
 *************************************************************************/
char *append(const char *s, char c) {
    int len =(int) strlen(s);
    char buf[len+2];
    strcpy(buf, s);
    buf[len] = c;
    buf[len + 1] = 0;
    return strdup(buf);
}
/************************************************************************
 name function: findPathFromConfFile
The Input: file descriptor and buffer
The output : the full new char* path
The function operation:add the buffer chars to the path
 *************************************************************************/
char* findPathFromConfFile(int fdinConf, char buf[SIZE]){
    int charReadNow=0;
    char* tempToBuildTheLine="";
    while ((int)buf[0] != 10) {
        charReadNow = (int)read(fdinConf, buf, SIZE);
        if (charReadNow == -1)  {
            perror("error by reading");
            return 0;
        }
        if((int)buf[0] != 10) {
            tempToBuildTheLine = append(tempToBuildTheLine, buf[0]);
        }
    }
    buf[0]=0;
    return  tempToBuildTheLine;
}
/************************************************************************
 name function: compare
The Input: name path, path to the right output, student struct,path
 comp.out path
The output : no output
The function operation:exectue a new process and update student struct
 *************************************************************************/
void compare(const char* name,char*rightOutputFile,
             struct studentInfo *studentInfoOne ,char*compOut) {
   // chdir(compOut);
    pid_t childPID3 = fork();
    if (childPID3 == 0) {//it child
        chdir(name);
        char *argsToCompile5[] = {compOut, "./output.txt", rightOutputFile, NULL};
        execvp(compOut, argsToCompile5);
    }
    int pid;
    int status;
    pid = wait(&status);

    waitpid(childPID3, 0, 0); /* wait for child to exit */
    switch WEXITSTATUS(status) {
        case 1: {//same
            studentInfoOne->SAME_OUTPUT = 1;
            break;
        }
        case 2: {//similar
            studentInfoOne->SAME_OUTPUT = 0;
            studentInfoOne->SIMILLAR_OUTPUT = 1;
            break;
        }
        case 3: {//diffrent
            studentInfoOne->SAME_OUTPUT = 0;
            studentInfoOne->BAD_OUTPUT = 1;
            break;
        }
    }
    kill(childPID3, SIGKILL);
}
/************************************************************************
 name function: listdir
The Input: name path, level of recursive,boolean find c file,
 student struct,,path inputFilepath rightOutputFile,path comp.out path
The output : 1 if there is file c,otherwise 0
The function operation:recursive all the subfolders
 *************************************************************************/
int listdir(const char *name, int level, int findC,
            struct studentInfo * studentInfoOne ,
            char* inputFile, char*rightOutputFile, char* compOut)
{
    DIR *dir;
    struct dirent *entry;

    if (!(dir = opendir(name)))
        return 0;
    if (!(entry = readdir(dir)))
        return 0 ;
    int thereCFile=0;
    int numFolders=-2;//because there are "." and ".." folders
    DIR *dirCheck;
    struct dirent *entryCheck;
    if (!(dirCheck = opendir(name)))
        return 0;
    if (!(entryCheck = readdir(dirCheck)))
        return 0 ;
    //*****
    do {
        if (entryCheck->d_type == DT_DIR) {//if it folder

        numFolders++;
        }
        else {///if if file

            if (strstr(entryCheck->d_name, ".c") != NULL) {
                thereCFile++;
            }
        }
    } while ((entryCheck = readdir(dirCheck))&&(findC==0));

    if((numFolders>1)&&(thereCFile==0)){
        studentInfoOne->MULTIPLE_DIRECTORIES=1;
    }
    //******
    do {
        if (entry->d_type == DT_DIR) {//if it folder
            char path[1024];
            int len = snprintf(path, sizeof(path) - 1, "%s/%s", name,
                               entry->d_name);
            path[len] = 0;
            if (strcmp(entry->d_name, ".") == 0 ||
                    strcmp(entry->d_name, "..") == 0)
                continue;
            printf("%*s[%s]\n", level * 2, "", entry->d_name);
            if (listdir(path, level + 1, findC, studentInfoOne, inputFile,
                        rightOutputFile,compOut) == 1) {
                return 1;
            }
        } else {///if if file

            if (strstr(entry->d_name, ".c") != NULL) {
                if (level > 1) {
                    studentInfoOne->WRONG_DIRECTORY = level - 1;
                }
                findC = 1;
                studentInfoOne->NO_C_FILE = 0;
                int pid;
                int exstat;
                int parentpid = getpid();
                pid_t childPID1 = fork();

                int status;

                if (childPID1 == 0) {// child process

                    char *onlyName[sizeof(entry->d_name)];
                    strcpy((char *) onlyName, entry->d_name);
                    chdir(name);
                    char *argsToCompile[] = {"cc", "-o", "./check.out",
                                             (char *) onlyName, NULL};
                    execvp("/usr/bin/cc", argsToCompile);
                } else {
                    //  waitpid(childPID1, 0, 0);
                   int status2=0;
                    int timer=0;
                    int stop=0;
                    pid_t pidCh;
                    while (timer<5&& !stop){
                        pidCh=waitpid(0,&status2,WNOHANG);
                        timer++;
                        if(pidCh==0){sleep(1);}
                        else{stop=1;}
                    }

                    if (WIFEXITED(status2)) {

                        if (WEXITSTATUS(status2) != 0) {
                            // Program failed but exited normally
                            studentInfoOne->ERROR_COMPILATION = 1;

                        } else {
                            if(timer>=5){
                                studentInfoOne->TIME_OUT=1;
                                kill(childPID1, SIGKILL);
                                break;
                            }
                            kill(childPID1, SIGKILL);
                            pid_t childPID2 = fork();
                            if (childPID2 == 0) {//it compile
                                int in, out;
                                // open input and output files
                                in = open(inputFile, O_RDONLY);
                                if (in < 0) {
                                    perror("error open file in");
                                    return 0;
                                }
                                char *outPath[sizeof(name)];
                                strcpy((char *) outPath, name);
                                strcat((char *) outPath, "/");
                                strcat((char *) outPath, "output.txt");
                                char *outputFullPath = (char *) outPath;
                                out = open(outputFullPath, O_CREAT |
                                                 O_WRONLY | O_RDONLY, 0666);
                                if (out < 0) {
                                    perror("error open file out");
                                    return 0;
                                }
                                // replace standard input with input file
                                dup2(in, 0);
                                // replace standard output with output file
                                dup2(out, 1);
                                char *checkPath[sizeof(name)];
                                strcpy((char *) checkPath, name);
                                strcat((char *) checkPath, "/");
                                strcat((char *) checkPath, "check.out");
                                char *checkFullPath = (char *) checkPath;
                                //chdir(name);
                                char *argsToCompile3[] = {"check.out", NULL};
                                int dummy;
                                chdir(name);
                                close(out);
                                close(in);
                                execvp("./check.out", argsToCompile3);



                            } else { /* pid!=0; parent process */
                                //   pid = wait(&status);
                               // wait(&status);
                                int status3=0;
                                int timer2=0;
                                int stop2=0;
                                pid_t pidCh2;
                                while (timer2<5&& !stop2){
                                    pidCh2=waitpid(0,&status3,WNOHANG);
                                    timer2++;
                                    if(pidCh2==0){sleep(1);}
                                    else{stop2=1;}
                                }
                                if (WIFEXITED(status3)) {

                                    if (WEXITSTATUS(status3) != 0) {
                                        // Program failed but exited normally

                                    } else {
                                        if(timer2>=5){
                                            studentInfoOne->TIME_OUT=1;
                                            kill(childPID1, SIGKILL);
                                            break;
                                        }
                                        compare(name,rightOutputFile,
                                                studentInfoOne,compOut);
                                        kill(childPID2, SIGKILL);
                                    }
                                }
                                compare(name,rightOutputFile,
                                        studentInfoOne,compOut);
                                kill(childPID2, SIGKILL);
                            }
                            kill(childPID1, SIGKILL);
                        }
                    }
                    printf("%*s- %s\n", level * 2, "", entry->d_name);
                }kill(childPID1, SIGKILL);
            }

        }
    } while ((entry = readdir(dir))&&(findC==0)&&
            (studentInfoOne->MULTIPLE_DIRECTORIES==0));

    closedir(dir);
    return findC;

}
/************************************************************************
 name function: printData
The Input: file descriptor, student struct,num of student to print
The output : no
The function operation:print all students data
 *************************************************************************/
void printData(int fdinRes, struct studentInfo
                    currentStudent[], int numOfStudent){
    int i=0;
    char  helpName[160]="0";

    while (i<numOfStudent) {
        helpName[160]="0";
        int charWrite;
        strcpy((char*)helpName,currentStudent[i].name);
        charWrite = (int) write(fdinRes, helpName, sizeof(helpName));
        if (charWrite < 0) {
            perror("writing name");
        }
        charWrite = 0;

        if (currentStudent[i].MULTIPLE_DIRECTORIES == 1) {//there is time out
            charWrite = (int) write(fdinRes, ",0,"
                    "MULTIPLE_DIRECTORIES", sizeof(",0,MULTIPLE_DIRECTORIES"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }
       else if (currentStudent[i].NO_C_FILE == 1)
        {//there is nooo file
            charWrite = (int) write(fdinRes, ",0,NO_C_FILE",
                                    sizeof(",0,NO_C_FILE"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }
        else if (currentStudent[i].ERROR_COMPILATION == 1)
        {//there is error compilation
            charWrite = (int) write(fdinRes, ",0,ERROR_COMPILATION",
                                    sizeof(",0,ERROR_COMPILATION"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }
        else if (currentStudent[i].TIME_OUT == 1) {//there is time out
            charWrite = (int) write(fdinRes, ",0,TIME_OUT",
                                    sizeof(",0,TIME_OUT"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }
        else if (currentStudent[i].WRONG_DIRECTORY >0) {
            int y=0;
            int x;
            if(currentStudent[i].SAME_OUTPUT==1){
                y=100;
            }
            if(currentStudent[i].SIMILLAR_OUTPUT==1){
                y=70;
            }
            x=y-10*currentStudent[i].WRONG_DIRECTORY;
            if(currentStudent[i].BAD_OUTPUT==1){
                x=0;
            }
            if(x<0){
                x=0;
            }
            char buf[4] = {0};
            snprintf(buf, sizeof x, "%d", x);

            charWrite = (int) write(fdinRes, ",", sizeof(","));
            if (charWrite < 0) {
                perror("writing name");
            }

            charWrite = (int) write(fdinRes, buf, sizeof(buf));

            if (charWrite < 0) {
                perror("writing name");
            }
            if(currentStudent[i].SAME_OUTPUT==1){
                charWrite = (int) write(fdinRes, ",SAME_OUTPUT",
                                        sizeof(",SAME_OUTPUT"));
                if (charWrite < 0) {
                    perror("writing name");
                }
                charWrite = 0;
            }
            if(currentStudent[i].SIMILLAR_OUTPUT==1){
                charWrite = (int) write(fdinRes, ",SIMILLAR_OUTPUT",
                                        sizeof(",SIMILLAR_OUTPUT"));
                if (charWrite < 0) {
                    perror("writing name");
                }
                charWrite = 0;
            }
            if(currentStudent[i].BAD_OUTPUT==1){
                charWrite = (int) write(fdinRes, ",BAD_OUTPUT",
                                        sizeof(",BAD_OUTPUT"));
                if (charWrite < 0) {
                    perror("writing name");
                }
                charWrite = 0;
            }
            charWrite = (int) write(fdinRes, ",WRONG_DIRECTORY",
                                    sizeof(",WRONG_DIRECTORY"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }

        else if (currentStudent[i].WRONG_DIRECTORY ==0&&
                currentStudent[i].BAD_OUTPUT==1) {
            charWrite = (int) write(fdinRes, ",0,BAD_OUTPUT",
                                    sizeof(",0,BAD_OUTPUT"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }
        else if (currentStudent[i].WRONG_DIRECTORY ==0&&
                currentStudent[i].SIMILLAR_OUTPUT==1) {
            charWrite = (int) write(fdinRes, ",70,SIMILLAR_OUTPUT",
                                    sizeof(",70,SIMILLAR_OUTPUT"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }
        else if (currentStudent[i].WRONG_DIRECTORY ==0&&
                currentStudent[i].SAME_OUTPUT==1) {
            charWrite = (int) write(fdinRes, ",100,GREAT_JOB",
                                    sizeof(",100,GREAT_JOB"));
            if (charWrite < 0) {
                perror("writing name");
            }
            charWrite = 0;
        }

        charWrite = (int) write(fdinRes, "\n", sizeof("\n"));
        if (charWrite < 0) {
            perror("writing name");
        }
        charWrite = 0;
        i++;
    }
}
/************************************************************************
 name function: deleteFile
The Input: name path, level of recursive
The output : 1 if there is succeed,otherwise 0
The function operation:recursive all the subfolders to find the files
 *************************************************************************/
int deleteFile(const char *name,int level) {
    DIR *dir;
    struct dirent *entry;
    int findC = 0;
    if (!(dir = opendir(name)))
        return 0;
    if (!(entry = readdir(dir)))
        return 0;
    do {
        if (entry->d_type == DT_DIR) {//if it folder
            char path[1024];
            int len = snprintf(path, sizeof(path) - 1, "%s/%s", name,
                               entry->d_name);
            path[len] = 0;
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name,
                                                          "..") == 0)
                continue;
            printf("%*s[%s]\n", level * 2, "", entry->d_name);
            if (deleteFile(path, level + 1) == 1) {
                return 1;
            }
        } else {///if if file
            if ((strstr(entry->d_name, ".out") != NULL)
                || (strstr(entry->d_name, ".txt")) != NULL) {
                char *resPath[sizeof(name)];
                strcpy((char *) resPath, name);
                strcat((char *) resPath, "/");
                strcat((char *) resPath, entry->d_name);
                char *destRes = (char *) resPath;
                unlink((const char*)resPath);
            }
        }
    } while ((entry = readdir(dir) ));
}
/************************************************************************
 name function: main
The Input: file configure
The output : 1 if there is succeed,otherwise 0
The function operation:run the program
 *************************************************************************/
int main(int argc, char * argv[]) {
    if (argc != 2) {
        perror("error- wrong input");
        return 0;
    }
    char* cwdComp;
    char buff[PATH_MAX + 1];

    cwdComp = getcwd( buff, PATH_MAX + 1 );
    if( cwdComp != NULL ) {
        printf( "My working directory is %s.\n", cwdComp );
    }
    strcat( cwdComp, "/");
    strcat( cwdComp, "comp.out");


    int fdinConf;//the input file descriptor
    //create the file with only read premissions
    fdinConf = open(argv[1], O_RDONLY);
    if (fdinConf < 0) {
        perror("error open file 1");
        return 0;
    }
    char buf[SIZE];//input/output buffer

    //save the first line from conf file
    char *mainFolder;
    mainFolder = findPathFromConfFile(fdinConf, buf);

    //save the second line from conf file
    char *inputFile;
    inputFile = findPathFromConfFile(fdinConf, buf);

    //save the third line from conf file
    char *rightOutputFile;
    rightOutputFile = findPathFromConfFile(fdinConf, buf);
    //****************************
    DIR *pDirMainCheck;
    struct dirent *pDirentMainCheck;
    if ((pDirMainCheck = opendir(mainFolder)) == NULL) {
        perror("error by open main folder");
    }

    //open the main folder
    DIR *pDirMain;
    struct dirent *pDirentMain;
    if ((pDirMain = opendir(mainFolder)) == NULL) {
        perror("error by open main folder");
    }
    //change dir to Main as "home"
    if (chdir(mainFolder) != 0) {
        perror("there is problem to change dir");
    }
    int fdinRes;//the output file descriptor
    //create the file with only read premissions
    char *resPath[sizeof(mainFolder)];
    strcpy((char *) resPath, mainFolder);
    strcat((char *) resPath, "/");
    strcat((char *) resPath, "results.csv");
    char *destRes = (char *) resPath;
    fdinRes = open(destRes, O_WRONLY | O_CREAT | O_RDONLY, 0666);
    if (fdinRes < 0) {
        perror("error open file results");
        return 0;
    }
    struct stat stat;
    DIR *pDirStudentFolder;
    int numOfStudent = 0;

    //check how much student we have in the main folder
    while ((pDirentMainCheck = readdir(pDirMainCheck)) != NULL) {
        char *nameF = pDirentMainCheck->d_name;
        lstat(nameF, &stat);

        //check if this is a folder of student
        if (S_ISDIR(stat.st_mode)) {
            printf("%s\n", pDirentMainCheck->d_name);
            if (strcmp(nameF, ".") == 0 || strcmp(nameF, "..") == 0) {
                continue;
            } else {
                numOfStudent++;
            }
        }
    }
    // looping through the directory, printing the directory entry name
    struct studentInfo currentStudent[numOfStudent];
    initStudenInfo(currentStudent, numOfStudent);
    int i = 0;
    char *nameF="";
    while ((pDirentMain = readdir(pDirMain)) != NULL) {
        nameF="";
        nameF = pDirentMain->d_name;
        lstat(nameF, &stat);
        //check if this is a folder of student
        if (S_ISDIR(stat.st_mode)) {
            printf("%s\n", pDirentMain->d_name);
            if (strcmp(nameF, ".") == 0 || strcmp(nameF, "..") == 0) {
                continue;
            }
            char *studentFolderPath[sizeof(mainFolder)];
            strcpy((char *) studentFolderPath, mainFolder);
            strcat((char *) studentFolderPath, "/");
            strcat((char *) studentFolderPath, pDirentMain->d_name);
            //open the student folder to check the files
            if ((pDirStudentFolder = opendir((char *) studentFolderPath)) == NULL) {
                perror("error by open main folder");
            }
            currentStudent[i].name = nameF;

            int g= listdir((char*)studentFolderPath,1,0,&currentStudent[i],
                           inputFile,rightOutputFile,cwdComp);
            if (g == 1) {
                printf("there is file\n \n");
            }
            deleteFile((char*)studentFolderPath,1);
            i++;
        }
    }
    printData(fdinRes, currentStudent, numOfStudent);
    close(fdinConf);
    close(fdinRes);
}
