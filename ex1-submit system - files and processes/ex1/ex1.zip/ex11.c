/******************************************
* Student name: Meital Birka
* Student: 311124283
* Course Exercise Group: 03
* Exercise name: Exercise 1
******************************************/
#include <stdio.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>

#define SIZE 1
/************************************************************************
 name function: main
The Input: file configure
The output : 1 if there is succeed,otherwise 0
The function operation:run the program
 *************************************************************************/
int main(int argc, char * argv[]) {

    if (argc != 3) {
        perror("error- wrong input");
        return 0;
    }

    char *firstPath = argv[1];
    char *secondPath = argv[2];
    int fdin1;//the first input file descriptor
    int fdin2;//the second input file descriptor
    char buf1[SIZE];//input/output buffer
    buf1[0]=0;
    char buf2[SIZE ];//input/output buffer
    buf2[0]=0;
    int charsr1;          // how many chars were actually read from file1
    int charsr2;          // how many chars were actually read from file2

    //create the file with only read premissions
    fdin1 = open(firstPath, O_RDONLY);
    if (fdin1 < 0) {
        perror("error open file 1");
        return 0;
    }
    //create the file with only read premissions
    fdin2 = open(secondPath, O_RDONLY);
    if (fdin2 < 0) {
        perror("error open file 2");
        return 0;
    }
    int text = 1;//save the mode of compare file-1equal,2same,3 diffrent
    do {
        charsr1 = (int)read(fdin1, buf1, SIZE);
        if (charsr1 == -1)  {
            perror("error by reading");
            return 0;
        }
        charsr2 = (int)read(fdin2, buf2, SIZE);
        if  (charsr2 == -1) {
            perror("error by reading");
            return 0;
        }
//one of the file done and the other not
        if ((charsr1 == 0) && (charsr2 > 0)) {
            text=3;
        }
        //one of the file done and the other not

        if ((charsr2 == 0) && (charsr1 > 0)) {
            text=3;
        }
        if (buf1[0] != buf2[0]) {//there are two chars same or difference
            //buf1 is new line=ascii 10,space 32
            if (((int) buf1[0] == 32) || (int) buf1[0] == 10 || (int) buf1[0] == 9) {
                while (((int) buf1[0] == 32) || ((int) buf1[0] == 10) || (int) buf1[0] == 9) {
                    text = 2;
                    charsr1 = (int)read(fdin1, buf1, SIZE);
                    if (charsr1 == -1) {
                        perror("error by reading");
                        return 0;
                    }
                    if (charsr1 == 0) {
                        break;
                    }
                }
            }
            //buf2 is new line=ascii 10,space 32
             if (((int) buf2[0] == 32) || (int) buf2[0] == 10 || (int) buf2[0] == 9) {
                while (((int) buf2[0] == 32) || ((int) buf2[0] == 10) || (int) buf2[0] == 9) {
                    text = 2;
                    charsr2 = (int)read(fdin2, buf2, SIZE);
                    if (charsr2 == -1) {
                        perror("error by reading");
                        return 0;
                    }
                    if (charsr2 == 0) {
                        break;                    }
                }
            }
             if (buf1[0] != buf2[0]) {

                 //if buf1 is upper and buf2 is lower
                 if (((((int) buf1[0] > 64) && ((int) buf1[0]) < 91)) &&
                     ((int) buf2[0] > 96) && (((int) buf2[0]) < 123)) {
                     if ((int) buf1[0] + 32 == (int) buf2[0]) {
                         text = 2;
                     }else {
                         text = 3;
                     }
                 }
                 //if buf2 is upper and buf1 is lower
                else if (((((int) buf2[0] > 64) && ((int) buf2[0]) < 91)) &&
                     ((int) buf1[0] > 96) && (((int) buf1[0]) < 123)) {
                     if ((int) buf2[0] + 32 == (int) buf1[0]) {
                         text = 2;
                     }
                     else {
                         text = 3;
                     }
                 } else if(charsr1!=charsr2){
                     text = 3;
                 }
             }
        }
        buf1[0]=0;
        buf2[0]=0;

    } while ((charsr1 == SIZE) && (charsr2 == SIZE));

    close(fdin1);        /* free allocated structures */
    close(fdin2);         /* free allocated structures */
    return text;

}